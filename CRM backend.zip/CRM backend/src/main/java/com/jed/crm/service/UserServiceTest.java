package main.java.com.jed.crm.service;

// service/UserServiceTest.java
@ExtendWith(MockitoExtension.class)
public class UserServiceTest {
    
    @Mock
    private UserRepository userRepository;
    
    @InjectMocks
    private UserServiceImpl userService;
    
    @Test
    public void whenCreateAdminUser_thenCorrectRoleIsAssigned() {
        UserDTO userDTO = new UserDTO();
        userDTO.setRole("ADMIN");
        userDTO.setName("Admin User");
        userDTO.setEmail("admin@test.com");
        
        when(userRepository.save(any(User.class))).thenAnswer(i -> i.getArgument(0));
        
        User createdUser = userService.createUser(userDTO);
        
        assertEquals("ADMIN", createdUser.getRole());
        verify(userRepository, times(1)).save(any(User.class));
    }
    
    @Test
    public void whenInvalidRole_thenThrowException() {
        UserDTO userDTO = new UserDTO();
        userDTO.setRole("INVALID");
        
        assertThrows(IllegalArgumentException.class, () -> userService.createUser(userDTO));
    }
}

// controller/AppointmentControllerTest.java
@WebMvcTest(AppointmentController.class)
public class AppointmentControllerTest {
    
    @Autowired
    private MockMvc mockMvc;
    
    @MockBean
    private AppointmentService appointmentService;
    
    @Test
    public void whenCreateAppointment_thenReturnsCreated() throws Exception {
        AppointmentDTO dto = new AppointmentDTO();
        dto.setDoctorId(1L);
        dto.setPatientId(1L);
        dto.setDateTime(LocalDateTime.now().plusDays(1));
        
        Appointment appointment = new Appointment();
        appointment.setId(1L);
        
        when(appointmentService.createAppointment(any(AppointmentDTO.class))).thenReturn(appointment);
        
        mockMvc.perform(post("/api/appointments")
               .contentType(MediaType.APPLICATION_JSON)
               .content(new ObjectMapper().writeValueAsString(dto)))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.id", is(1)));
    }
}