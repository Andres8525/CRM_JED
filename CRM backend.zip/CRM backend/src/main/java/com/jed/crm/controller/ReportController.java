package main.java.com.jed.crm.controller;

// controller/ReportController.java
@RestController
@RequestMapping("/api/reports")
public class ReportController {
    private final ReportService reportService;
    
    @Autowired
    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }
    
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<byte[]> generatePatientReport(@PathVariable Long patientId) {
        byte[] report = reportService.generateReport("PATIENT", patientId);
        
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, 
                   "attachment; filename=reporte-paciente.pdf")
            .contentType(MediaType.APPLICATION_PDF)
            .body(report);
    }
    
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<byte[]> generateDoctorReport(@PathVariable Long doctorId) {
        byte[] report = reportService.generateReport("DOCTOR", doctorId);
        
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, 
                   "attachment; filename=reporte-medico.pdf")
            .contentType(MediaType.APPLICATION_PDF)
            .body(report);
    }
}