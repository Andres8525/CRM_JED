// model/DailySchedule.java
public class DailySchedule {
    private Node firstAppointment;
    
    private static class Node {
        Appointment appointment;
        Node next;
        
        Node(Appointment appointment) {
            this.appointment = appointment;
        }
    }
    
    public void addAppointment(Appointment appointment) {
        Node newNode = new Node(appointment);
        
        if (firstAppointment == null || 
            appointment.getDateTime().isBefore(firstAppointment.appointment.getDateTime())) {
            newNode.next = firstAppointment;
            firstAppointment = newNode;
            return;
        }
        
        Node current = firstAppointment;
        while (current.next != null && 
               current.next.appointment.getDateTime().isBefore(appointment.getDateTime())) {
            current = current.next;
        }
        
        newNode.next = current.next;
        current.next = newNode;
    }
    
    public List<Appointment> getAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        Node current = firstAppointment;
        while (current != null) {
            appointments.add(current.appointment);
            current = current.next;
        }
        return appointments;
    }
}