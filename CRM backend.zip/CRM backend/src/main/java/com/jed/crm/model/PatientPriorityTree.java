// model/PatientPriorityTree.java
public class PatientPriorityTree {
    private Node root;
    
    private static class Node {
        Patient patient;
        int priority;
        int height;
        Node left, right;
        
        Node(Patient patient, int priority) {
            this.patient = patient;
            this.priority = priority;
            this.height = 1;
        }
    }
    
    // Métodos AVL estándar (insert, delete, search, rotations)
    // Ordenados por prioridad
    
    public void insert(Patient patient, int priority) {
        root = insert(root, patient, priority);
    }
    
    private Node insert(Node node, Patient patient, int priority) {
        if (node == null) {
            return new Node(patient, priority);
        }
        
        if (priority < node.priority) {
            node.left = insert(node.left, patient, priority);
        } else if (priority > node.priority) {
            node.right = insert(node.right, patient, priority);
        } else {
            return node; // No se permiten duplicados
        }
        
        // Actualizar altura
        node.height = 1 + Math.max(height(node.left), height(node.right));
        
        // Balancear el árbol
        int balance = getBalance(node);
        
        // Casos de desbalance
        if (balance > 1 && priority < node.left.priority) {
            return rightRotate(node);
        }
        
        if (balance < -1 && priority > node.right.priority) {
            return leftRotate(node);
        }
        
        if (balance > 1 && priority > node.left.priority) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        }
        
        if (balance < -1 && priority < node.right.priority) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        }
        
        return node;
    }
    
    // Métodos auxiliares para rotaciones y balance
    private int height(Node node) {
        return node == null ? 0 : node.height;
    }
    
    private int getBalance(Node node) {
        return node == null ? 0 : height(node.left) - height(node.right);
    }
    
    private Node rightRotate(Node y) {
        Node x = y.left;
        Node T2 = x.right;
        
        x.right = y;
        y.left = T2;
        
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        
        return x;
    }
    
    private Node leftRotate(Node x) {
        Node y = x.right;
        Node T2 = y.left;
        
        y.left = x;
        x.right = T2;
        
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;
        
        return y;
    }
    
    public List<Patient> getPatientsInOrder() {
        List<Patient> patients = new ArrayList<>();
        inOrder(root, patients);
        return patients;
    }
    
    private void inOrder(Node node, List<Patient> patients) {
        if (node != null) {
            inOrder(node.left, patients);
            patients.add(node.patient);
            inOrder(node.right, patients);
        }
    }
}