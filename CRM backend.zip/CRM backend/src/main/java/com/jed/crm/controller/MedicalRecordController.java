package main.java.com.jed.crm.controller;

// controller/MedicalRecordController.java
@RestController
@RequestMapping("/api/medical-records")
public class MedicalRecordController {
    private final MedicalRecordService medicalRecordService;
    
    @Autowired
    public MedicalRecordController(MedicalRecordService medicalRecordService) {
        this.medicalRecordService = medicalRecordService;
    }
    
    @PostMapping
    public ResponseEntity<MedicalRecord> createMedicalRecord(
            @RequestBody MedicalRecordDTO recordDTO) {
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(medicalRecordService.createMedicalRecord(recordDTO));
    }
    
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<List<MedicalRecord>> getPatientRecords(
            @PathVariable Long patientId) {
        return ResponseEntity.ok(medicalRecordService.findByPatient(patientId));
    }
    
    @GetMapping("/{id}/export")
    public ResponseEntity<byte[]> exportMedicalRecord(@PathVariable Long id) {
        byte[] report = medicalRecordService.exportMedicalRecord(id);
        
        return ResponseEntity.ok()
            .header(HttpHeaders.CONTENT_DISPOSITION, 
                   "attachment; filename=historial-medico.pdf")
            .contentType(MediaType.APPLICATION_PDF)
            .body(report);
    }
}