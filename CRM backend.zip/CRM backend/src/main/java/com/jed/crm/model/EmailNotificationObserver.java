// model/observer/NotificationObserver.java
public interface NotificationObserver {
    void update(String message, String recipient);
}

// model/observer/EmailNotification.java
@Service
public class EmailNotificationObserver implements NotificationObserver {
    @Override
    public void update(String message, String recipient) {
        // Implementar lógica de envío por email
        System.out.println("Enviando email a " + recipient + ": " + message);
    }
}

// model/observer/SMSNotification.java
@Service
public class SMSNotification implements NotificationObserver {
    @Override
    public void update(String message, String recipient) {
        // Implementar lógica de envío por SMS
        System.out.println("Enviando SMS a " + recipient + ": " + message);
    }
}

// service/impl/AppointmentServiceImpl.java (fragmento)
@Service
public class AppointmentServiceImpl implements AppointmentService {
    private final List<NotificationObserver> observers = new ArrayList<>();
    
    @Autowired
    public AppointmentServiceImpl(EmailNotificationObserver emailNotification, 
                                 SMSNotification smsNotification) {
        observers.add(emailNotification);
        observers.add(smsNotification);
    }
    
    private void notifyObservers(String message, String recipient) {
        observers.forEach(observer -> observer.update(message, recipient));
    }
    
    @Override
    public Appointment createAppointment(Appointment appointment) {
        // Lógica para crear cita
        String message = "Nueva cita programada para " + appointment.getDate();
        notifyObservers(message, appointment.getPatient().getEmail());
        return appointmentRepository.save(appointment);
    }
}