package main.java.com.jed.crm.service.impl;

// service/impl/PatientServiceImpl.java (fragmento)
@Service
public class PatientServiceImpl implements PatientService {
    private final PatientRepository patientRepository;
    private final Map<String, Patient> patientCache = new HashMap<>();
    
    @Autowired
    public PatientServiceImpl(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }
    
    @Override
    public Patient findByIdentification(String identification) {
        // Buscar primero en cache
        if (patientCache.containsKey(identification)) {
            return patientCache.get(identification);
        }
        
        // Si no está en cache, buscar en BD
        Patient patient = patientRepository.findByIdentification(identification)
            .orElseThrow(() -> new ResourceNotFoundException("Patient not found"));
        
        // Agregar a cache
        patientCache.put(identification, patient);
        
        return patient;
    }
    
    @Override
    @CacheEvict(value = "patients", key = "#patient.identification")
    public Patient updatePatient(Patient patient) {
        // Actualizar en BD
        Patient updatedPatient = patientRepository.save(patient);
        
        // Actualizar cache
        patientCache.put(patient.getIdentification(), updatedPatient);
        
        return updatedPatient;
    }
}