package main.java.com.jed.crm.service;

// service/NotificationAdapter.java
public interface NotificationAdapter {
    void send(String message, String recipient);
}

// service/impl/EmailAdapter.java
@Service
public class EmailAdapter implements NotificationAdapter {
    @Override
    public void send(String message, String recipient) {
        // Lógica específica para enviar email
    }
}

// service/impl/WhatsAppAdapter.java
@Service
public class WhatsAppAdapter implements NotificationAdapter {
    @Override
    public void send(String message, String recipient) {
        // Lógica específica para enviar WhatsApp
    }
}

// service/impl/NotificationService.java
@Service
public class NotificationService {
    private final Map<String, NotificationAdapter> adapters;
    
    @Autowired
    public NotificationService(EmailAdapter emailAdapter, 
                              WhatsAppAdapter whatsAppAdapter) {
        adapters = new HashMap<>();
        adapters.put("EMAIL", emailAdapter);
        adapters.put("WHATSAPP", whatsAppAdapter);
    }
    
    public void sendNotification(String type, String message, String recipient) {
        NotificationAdapter adapter = adapters.get(type.toUpperCase());
        if (adapter != null) {
            adapter.send(message, recipient);
        } else {
            throw new IllegalArgumentException("Invalid notification type");
        }
    }
}