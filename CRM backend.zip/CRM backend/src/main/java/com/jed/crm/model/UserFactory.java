// model/factory/UserFactory.java
public interface User {
    String getRole();
}

// model/factory/Admin.java
public class Admin implements User {
    @Override
    public String getRole() { return "ADMIN"; }
}

// model/factory/Doctor.java
public class Doctor implements User {
    @Override
    public String getRole() { return "DOCTOR"; }
}

// model/factory/Patient.java
public class Patient implements User {
    @Override
    public String getRole() { return "PATIENT"; }
}

// model/factory/UserFactory.java
public class UserFactory {
    public static User createUser(String type) {
        return switch(type.toUpperCase()) {
            case "ADMIN" -> new Admin();
            case "DOCTOR" -> new Doctor();
            case "PATIENT" -> new Patient();
            default -> throw new IllegalArgumentException("Invalid user type");
        };
    }
}