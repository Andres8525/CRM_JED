// service/impl/NotificationQueueService.java
@Service
public class NotificationQueueService {
    private final Queue<NotificationTask> notificationQueue = new LinkedList<>();
    private final NotificationService notificationService;
    
    @Autowired
    public NotificationQueueService(NotificationService notificationService) {
        this.notificationService = notificationService;
    }
    
    public void addNotification(NotificationTask task) {
        notificationQueue.add(task);
    }
    
    @Scheduled(fixedRate = 5000) // Ejecutar cada 5 segundos
    public void processNotifications() {
        while (!notificationQueue.isEmpty()) {
            NotificationTask task = notificationQueue.poll();
            try {
                notificationService.sendNotification(
                    task.getType(), 
                    task.getMessage(), 
                    task.getRecipient()
                );
            } catch (Exception e) {
                // Reintentar o registrar fallo
                notificationQueue.add(task);
            }
        }
    }
}

// model/NotificationTask.java
public class NotificationTask {
    private String type;
    private String message;
    private String recipient;
    
    // Constructor, getters y setters
}