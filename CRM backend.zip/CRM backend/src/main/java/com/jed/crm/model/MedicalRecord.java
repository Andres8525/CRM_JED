// model/builder/MedicalRecord.java
@Entity
@Table(name = "medical_records")
public class MedicalRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String diagnosis;
    private String treatment;
    private String observations;
    private LocalDate date;
    
    // Getters and setters
    
    public static class Builder {
        private final MedicalRecord record = new MedicalRecord();
        
        public Builder withDiagnosis(String diagnosis) {
            record.setDiagnosis(diagnosis);
            return this;
        }
        
        public Builder withTreatment(String treatment) {
            record.setTreatment(treatment);
            return this;
        }
        
        public Builder withObservations(String observations) {
            record.setObservations(observations);
            return this;
        }
        
        public Builder withDate(LocalDate date) {
            record.setDate(date);
            return this;
        }
        
        public MedicalRecord build() {
            if (record.getDate() == null) {
                record.setDate(LocalDate.now());
            }
            return record;
        }
    }
}