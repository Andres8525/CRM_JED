package main.java.com.jed.crm.service;

// service/strategy/ReportStrategy.java
public interface ReportStrategy {
    byte[] generateReport(Long id);
}

// service/strategy/DoctorReportStrategy.java
@Service
public class DoctorReportStrategy implements ReportStrategy {
    @Override
    public byte[] generateReport(Long doctorId) {
        // Lógica para generar reporte de médico
        return new byte[0]; // Retornar PDF/Excel
    }
}

// service/strategy/PatientReportStrategy.java
@Service
public class PatientReportStrategy implements ReportStrategy {
    @Override
    public byte[] generateReport(Long patientId) {
        // Lógica para generar reporte de paciente
        return new byte[0]; // Retornar PDF/Excel
    }
}

// service/impl/ReportServiceImpl.java
@Service
public class ReportServiceImpl implements ReportService {
    private final Map<String, ReportStrategy> strategies;
    
    @Autowired
    public ReportServiceImpl(DoctorReportStrategy doctorStrategy,
                           PatientReportStrategy patientStrategy) {
        strategies = new HashMap<>();
        strategies.put("DOCTOR", doctorStrategy);
        strategies.put("PATIENT", patientStrategy);
    }
    
    @Override
    public byte[] generateReport(String type, Long id) {
        ReportStrategy strategy = strategies.get(type.toUpperCase());
        if (strategy != null) {
            return strategy.generateReport(id);
        }
        throw new IllegalArgumentException("Invalid report type");
    }
}