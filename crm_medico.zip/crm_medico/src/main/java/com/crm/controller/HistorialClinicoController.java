package com.crm.controller;

import com.crm.model.HistorialClinico;
import com.crm.service.HistorialClinicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/historiales")
public class HistorialClinicoController {

    @Autowired
    private HistorialClinicoService historialClinicoService;

    // ✅ POST: Guardar un nuevo historial clínico
    @PostMapping
    public ResponseEntity<HistorialClinico> guardar(@RequestBody HistorialClinico historial) {
        try {
            HistorialClinico guardado = historialClinicoService.guardar(historial);
            return ResponseEntity.ok(guardado);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    // ✅ GET: Listar todos los historiales clínicos
    @GetMapping
    public ResponseEntity<List<HistorialClinico>> listarTodos() {
        try {
            List<HistorialClinico> historiales = historialClinicoService.listarTodos();
            return ResponseEntity.ok(historiales);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    // ✅ GET: Obtener historiales clínicos por ID de cita
    @GetMapping("/cita/{idCita}")
    public ResponseEntity<List<HistorialClinico>> obtenerPorIdCita(@PathVariable String idCita) {
        try {
            List<HistorialClinico> historiales = historialClinicoService.buscarPorIdCita(idCita);
            return ResponseEntity.ok(historiales);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    // ✅ DELETE: Eliminar historial por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> eliminar(@PathVariable String id) {
        try {
            historialClinicoService.eliminarPorId(id);
            return ResponseEntity.ok("Historial eliminado correctamente");
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error al eliminar el historial clínico.");
        }
    }
}
