package com.crm.controller;

import com.crm.model.Cita;
import com.crm.model.HistorialClinico;
import com.crm.service.CitaService;
import com.crm.service.HistorialClinicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/citas")
public class CitaController {

    @Autowired
    private CitaService citaService;

    @Autowired
    private HistorialClinicoService historialClinicoService;

    // ✅ GET: Obtener una cita y su historial clínico
    @GetMapping("/{id}")
    public ResponseEntity<Map<String, Object>> obtenerCitaConHistorial(@PathVariable String id) {
        Optional<Cita> citaOpt = citaService.buscarPorId(id);
        if (citaOpt.isEmpty()) {
            return ResponseEntity.status(404).body(Map.of("error", "Cita no encontrada"));
        }

        List<HistorialClinico> historiales = historialClinicoService.buscarPorIdCita(id);
        Map<String, Object> response = new HashMap<>();
        response.put("cita", citaOpt.get());
        response.put("historiales", historiales);
        return ResponseEntity.ok(response);
    }

    // ✅ POST: Agendar nueva cita
    @PostMapping
    public ResponseEntity<Cita> agendar(@RequestBody Cita cita) {
        try {
            Cita nueva = citaService.agendar(cita);
            return ResponseEntity.ok(nueva);
        } catch (RuntimeException e) {
            return ResponseEntity.status(409).body(null); // Conflicto por cita ya existente
        }
    }

    // ✅ GET: Listar todas las citas
    @GetMapping
    public ResponseEntity<List<Cita>> listarCitas() {
        return ResponseEntity.ok(citaService.listar());
    }

    // ✅ GET: Listar citas por estado (ej: AGENDADA, CANCELADA)
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<Cita>> listarPorEstado(@PathVariable String estado) {
        return ResponseEntity.ok(citaService.listarPorEstado(estado));
    }

    // ✅ DELETE: Eliminar una cita (si no tiene historial)
    @DeleteMapping("/{id}")
    public ResponseEntity<String> cancelarCita(@PathVariable String id) {
        try {
            citaService.eliminar(id);
            return ResponseEntity.ok("Cita eliminada correctamente");
        } catch (IllegalStateException e) {
            return ResponseEntity.status(409).body(e.getMessage());
        } catch (NoSuchElementException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }
}
