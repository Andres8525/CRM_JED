package com.crm.service;

import com.crm.model.Usuario;
import com.crm.repository.CitaRepository;
import com.crm.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private CitaRepository citaRepository;

    public Usuario guardar(Usuario usuario) {
        return usuarioRepository.save(usuario);
    }

    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    public void eliminar(String id) {
        Usuario usuario = usuarioRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("No se encontró un usuario con el ID: " + id));

        boolean tieneCitas = false;

        // ✅ Convertimos el enum a texto
        String rolNombre = usuario.getRol().name();

        if ("MEDICO".equalsIgnoreCase(rolNombre)) {
            tieneCitas = !citaRepository.findByIdMedico(id).isEmpty();
        } else if ("PACIENTE".equalsIgnoreCase(rolNombre)) {
            tieneCitas = !citaRepository.findByIdPaciente(id).isEmpty();
        }

        if (tieneCitas) {
            throw new IllegalStateException("No se puede eliminar al usuario con rol '" + rolNombre + "' porque tiene citas registradas.");
        }

        usuarioRepository.deleteById(id);
    }
}
