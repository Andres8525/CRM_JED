package com.crm.service;

import com.crm.model.HistorialClinico;

import java.util.List;
import java.util.Optional;

public interface HistorialClinicoService {
    
    // ✅ Guardar un nuevo historial clínico
    HistorialClinico guardar(HistorialClinico historial);

    // ✅ Obtener el primer historial de una cita (opcional)
    Optional<HistorialClinico> obtenerPorCita(String idCita);

    // ✅ Obtener todos los historiales asociados a una cita
    List<HistorialClinico> buscarPorIdCita(String idCita);

    // ✅ Listar todos los historiales clínicos
    List<HistorialClinico> listarTodos();

    // ✅ Eliminar un historial por su ID
    void eliminarPorId(String id);
}
