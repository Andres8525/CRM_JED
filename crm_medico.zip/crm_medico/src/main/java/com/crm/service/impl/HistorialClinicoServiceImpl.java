package com.crm.service.impl;

import com.crm.model.HistorialClinico;
import com.crm.repository.HistorialClinicoRepository;
import com.crm.service.HistorialClinicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.NoSuchElementException;

@Service
public class HistorialClinicoServiceImpl implements HistorialClinicoService {

    @Autowired
    private HistorialClinicoRepository historialClinicoRepository;

    // ✅ Guarda un historial clínico nuevo
    @Override
    public HistorialClinico guardar(HistorialClinico historial) {
        return historialClinicoRepository.save(historial);
    }

    // ✅ Retorna solo el primer historial encontrado por id de cita
    @Override
    public Optional<HistorialClinico> obtenerPorCita(String idCita) {
        return historialClinicoRepository.findByIdCita(idCita)
                                         .stream()
                                         .findFirst();
    }

    // ✅ Retorna todos los historiales asociados a una cita
    @Override
    public List<HistorialClinico> buscarPorIdCita(String idCita) {
        return historialClinicoRepository.findByIdCita(idCita);
    }

    // ✅ Retorna todos los historiales clínicos en general
    @Override
    public List<HistorialClinico> listarTodos() {
        return historialClinicoRepository.findAll();
    }

    // ✅ Elimina un historial por su ID
    @Override
    public void eliminarPorId(String id) {
        if (!historialClinicoRepository.existsById(id)) {
            throw new NoSuchElementException("No se encontró un historial con el ID: " + id);
        }
        historialClinicoRepository.deleteById(id);
    }
}
