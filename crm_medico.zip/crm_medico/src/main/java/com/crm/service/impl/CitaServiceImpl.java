package com.crm.service.impl;

import com.crm.model.Cita;
import com.crm.repository.CitaRepository;
import com.crm.service.CitaService;
import com.crm.service.HistorialClinicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CitaServiceImpl implements CitaService {

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private HistorialClinicoService historialClinicoService;

    // ✅ Agendar nueva cita, validando disponibilidad del médico
    @Override
    public Cita agendar(Cita cita) {
        boolean yaExiste = citaRepository
                .findByIdMedicoAndFechaHora(cita.getIdMedico(), cita.getFechaHora())
                .isPresent();

        if (yaExiste) {
            throw new RuntimeException("Ya existe una cita agendada para ese médico en esa hora.");
        }

        cita.setEstado("AGENDADA");
        return citaRepository.save(cita);
    }

    // ✅ Listar todas las citas
    @Override
    public List<Cita> listar() {
        return citaRepository.findAll();
    }

    // ✅ Listar citas por estado (nuevo)
    @Override
    public List<Cita> listarPorEstado(String estado) {
        return citaRepository.findByEstado(estado);
    }

    // ✅ Eliminar una cita solo si no tiene historial clínico
    @Override
    public void eliminar(String id) {
        if (!citaRepository.existsById(id)) {
            throw new IllegalArgumentException("No existe una cita con el ID: " + id);
        }

        boolean tieneHistorial = !historialClinicoService.buscarPorIdCita(id).isEmpty();
        if (tieneHistorial) {
            throw new IllegalStateException("No se puede eliminar la cita porque tiene historial clínico registrado.");
        }

        citaRepository.deleteById(id);
    }

    // ✅ Buscar una cita por ID
    @Override
    public Optional<Cita> buscarPorId(String id) {
        return citaRepository.findById(id);
    }
}
