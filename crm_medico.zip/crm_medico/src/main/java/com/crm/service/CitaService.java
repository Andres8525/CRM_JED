package com.crm.service;

import com.crm.model.Cita;

import java.util.List;
import java.util.Optional;

public interface CitaService {
    Cita agendar(Cita cita);
    List<Cita> listar(); // Lista todas las citas
    List<Cita> listarPorEstado(String estado); // Lista citas por estado (AGENDADA, CANCELADA, etc.)
    Optional<Cita> buscarPorId(String id); // Busca una cita por su ID
    void eliminar(String id); // Elimina una cita si no tiene historial clínico
}
