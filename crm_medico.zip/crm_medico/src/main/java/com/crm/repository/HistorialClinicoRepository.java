package com.crm.repository;

import com.crm.model.HistorialClinico;
import org.springframework.data.mongodb.repository.MongoRepository;
import java.util.List;

public interface HistorialClinicoRepository extends MongoRepository<HistorialClinico, String> {

    // Buscar historiales clínicos asociados a una cita específica
    List<HistorialClinico> findByIdCita(String idCita);
}
