package com.crm.repository;

import com.crm.model.Cita;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface CitaRepository extends MongoRepository<Cita, String> {

    Optional<Cita> findByIdMedicoAndFechaHora(String idMedico, LocalDateTime fechaHora);

    List<Cita> findByIdMedico(String idMedico);

    List<Cita> findByIdPaciente(String idPaciente);

    List<Cita> findByEstado(String estado); // 🔹 corregido: antes estaba mal escrito (finByEstado)
}
