package com.crm.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;

@Document(collection = "citas")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cita {

    @Id
    private String id;

    private String idPaciente;

    private String idMedico;

    private LocalDateTime fechaHora;

    private String estado; // AGENDADA, CANCELADA, COMPLETADA
}
