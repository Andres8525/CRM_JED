package com.crm.model;

public enum Rol {
    ADMIN,
    MEDICO,
    PACIENTE
}
