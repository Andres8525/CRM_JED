package com.crm.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "historiales")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HistorialClinico {

    @Id
    private String id;

    private String idCita;

    private String diagnostico;

    private String tratamiento;

    private String notas;
}
