package com.crm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrmMedicoApplication {
    public static void main(String[] args) {
        SpringApplication.run(CrmMedicoApplication.class, args);
    }
}
