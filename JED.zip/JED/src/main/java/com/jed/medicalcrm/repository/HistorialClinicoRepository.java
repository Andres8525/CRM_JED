package com.jed.medicalcrm.repository;

import com.jed.medicalcrm.model.HistorialClinico;
import com.jed.medicalcrm.model.Paciente;
import com.jed.medicalcrm.model.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HistorialClinicoRepository extends JpaRepository<HistorialClinico, Long> {
    List<HistorialClinico> findByPacienteId(Long pacienteId);
    List<HistorialClinico> findByMedicoId(Long medicoId);
    List<HistorialClinico> findByPaciente(Paciente paciente);
    List<HistorialClinico> findByMedico(Medico medico);
}
