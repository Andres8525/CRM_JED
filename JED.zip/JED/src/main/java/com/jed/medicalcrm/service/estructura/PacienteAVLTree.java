package com.jed.medicalcrm.service.estructura;

import com.jed.medicalcrm.model.Paciente;

public class PacienteAVLTree {

    private class Nodo {
        Paciente paciente;
        int prioridad;
        int altura;
        Nodo izquierda, derecha;

        Nodo(Paciente paciente, int prioridad) {
            this.paciente = paciente;
            this.prioridad = prioridad;
            this.altura = 1;
        }
    }

    private Nodo raiz;

    // Public: insertar
    public void insertar(Paciente paciente, int prioridad) {
        raiz = insertar(raiz, paciente, prioridad);
    }

    // Public: obtener paciente con mayor prioridad (izquierda profunda)
    public Paciente obtenerMayorPrioridad() {
        Nodo nodo = obtenerNodoMaxPrioridad(raiz);
        return nodo != null ? nodo.paciente : null;
    }

    // Interno: insertar y balancear
    private Nodo insertar(Nodo nodo, Paciente paciente, int prioridad) {
        if (nodo == null) return new Nodo(paciente, prioridad);

        if (prioridad < nodo.prioridad) {
            nodo.izquierda = insertar(nodo.izquierda, paciente, prioridad);
        } else {
            nodo.derecha = insertar(nodo.derecha, paciente, prioridad);
        }

        nodo.altura = 1 + Math.max(altura(nodo.izquierda), altura(nodo.derecha));
        return balancear(nodo);
    }

    private Nodo balancear(Nodo nodo) {
        int balance = getBalance(nodo);

        if (balance > 1) {
            if (getBalance(nodo.izquierda) < 0) {
                nodo.izquierda = rotarIzquierda(nodo.izquierda);
            }
            return rotarDerecha(nodo);
        }

        if (balance < -1) {
            if (getBalance(nodo.derecha) > 0) {
                nodo.derecha = rotarDerecha(nodo.derecha);
            }
            return rotarIzquierda(nodo);
        }

        return nodo;
    }

    private Nodo rotarDerecha(Nodo y) {
        Nodo x = y.izquierda;
        Nodo T2 = x.derecha;

        x.derecha = y;
        y.izquierda = T2;

        y.altura = Math.max(altura(y.izquierda), altura(y.derecha)) + 1;
        x.altura = Math.max(altura(x.izquierda), altura(x.derecha)) + 1;

        return x;
    }

    private Nodo rotarIzquierda(Nodo x) {
        Nodo y = x.derecha;
        Nodo T2 = y.izquierda;

        y.izquierda = x;
        x.derecha = T2;

        x.altura = Math.max(altura(x.izquierda), altura(x.derecha)) + 1;
        y.altura = Math.max(altura(y.izquierda), altura(y.derecha)) + 1;

        return y;
    }

    private int altura(Nodo nodo) {
        return nodo == null ? 0 : nodo.altura;
    }

    private int getBalance(Nodo nodo) {
        return nodo == null ? 0 : altura(nodo.izquierda) - altura(nodo.derecha);
    }

    private Nodo obtenerNodoMaxPrioridad(Nodo nodo) {
        if (nodo == null) return null;
        return nodo.derecha == null ? nodo : obtenerNodoMaxPrioridad(nodo.derecha);
    }
}
