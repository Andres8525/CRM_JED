package com.jed.medicalcrm.service.notificacion;

import com.jed.medicalcrm.dto.NotificacionDTO;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class NotificacionService {

    private final List<Observador> observadores = new ArrayList<>();

    public void enviarNotificacion(NotificacionDTO dto) {
        Observador canal = EstrategiaNotificacion.obtenerEstrategia(dto.getTipo());
        observadores.add(canal); // registramos solo el necesario
        notificar(dto.getMensaje(), dto.getDestino());
        observadores.clear(); // para evitar acumulación
    }

    private void notificar(String mensaje, String destino) {
        for (Observador o : observadores) {
            o.actualizar(mensaje, destino);
        }
    }
}
