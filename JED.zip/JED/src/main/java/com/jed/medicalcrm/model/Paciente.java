

package com.jed.medicalcrm.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class Paciente extends Usuario {
    
    private String nombreCompleto;
    private int edad;
    private Date fechaNacimiento;
    private String genero;
    private String tipoSangre;
    private String direccion;
    private String historiaClinica;
    
    @OneToMany(mappedBy = "paciente")
    private List<HistorialClinico> historialClinico = new ArrayList<>();
    
    // Constructor por defecto requerido por JPA
    public Paciente() {
    }
    
    // Getters y setters
    public String getNombreCompleto() {
        return nombreCompleto;
    }
    
    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }
    
    public int getEdad() {
        return edad;
    }
    
    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }
    
    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    
    public String getGenero() {
        return genero;
    }
    
    public void setGenero(String genero) {
        this.genero = genero;
    }
    
    public String getTipoSangre() {
        return tipoSangre;
    }
    
    public void setTipoSangre(String tipoSangre) {
        this.tipoSangre = tipoSangre;
    }
    
    public String getDireccion() {
        return direccion;
    }
    
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    public String getHistoriaClinica() {
        return historiaClinica;
    }
    
    public void setHistoriaClinica(String historiaClinica) {
        this.historiaClinica = historiaClinica;
    }
    
    public List<HistorialClinico> getHistorialClinico() {
        return historialClinico;
    }
    
    public void setHistorialClinico(List<HistorialClinico> historialClinico) {
        this.historialClinico = historialClinico;
    }
}
