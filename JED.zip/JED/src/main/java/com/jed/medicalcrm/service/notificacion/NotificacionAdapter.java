package com.jed.medicalcrm.service.notificacion;

public interface NotificacionAdapter {
    void enviar(String destino, String mensaje);
}
