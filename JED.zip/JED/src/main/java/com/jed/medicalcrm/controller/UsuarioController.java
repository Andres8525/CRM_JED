package com.jed.medicalcrm.controller;

import com.jed.medicalcrm.dto.UsuarioDTO;
import com.jed.medicalcrm.service.usuario.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping
    public ResponseEntity<UsuarioDTO> crearUsuario(@RequestBody UsuarioDTO usuarioDTO) {
        UsuarioDTO creado = usuarioService.crearUsuario(usuarioDTO);
        return ResponseEntity.ok(creado);
    }
    
    // Aquí podrían ir otros endpoints como:
    // - Obtener usuario por ID
    // - Actualizar usuario
    // - Eliminar usuario
    // - Listar usuarios
}
