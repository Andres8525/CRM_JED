package com.jed.medicalcrm.model;

import jakarta.persistence.*;
import java.util.Date;

/**
 * Entidad para gestionar documentos adjuntos a los historiales clínicos como:
 * - Resultados de exámenes médicos
 * - Radiografías
 * - Recetas médicas
 * - Informes de especialistas
 */
@Entity
@Table(name = "documentos")
public class Documento {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "historial_id", nullable = false)
    private HistorialClinico historialClinico;
    
    @Column(nullable = false)
    private String nombre;
    
    @Column(nullable = false)
    private String tipo; // Tipo MIME: application/pdf, image/jpeg, etc.
    
    @Column(nullable = false)
    private String rutaArchivo;
    
    private Long tamano; // en bytes
    
    @Column(name = "descripcion", length = 500)
    private String descripcion;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false, updatable = false)
    private Date fechaSubida = new Date();
    
    @Column(name = "subido_por")
    private String subidoPor; // Username del usuario que subió el documento
    
    /**
     * Constructor por defecto requerido por JPA
     */
    public Documento() {
    }
    
    /**
     * Constructor con los campos obligatorios
     */
    public Documento(HistorialClinico historialClinico, String nombre, String tipo, String rutaArchivo) {
        this.historialClinico = historialClinico;
        this.nombre = nombre;
        this.tipo = tipo;
        this.rutaArchivo = rutaArchivo;
    }
    
    // Getters y setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public HistorialClinico getHistorialClinico() {
        return historialClinico;
    }
    
    public void setHistorialClinico(HistorialClinico historialClinico) {
        this.historialClinico = historialClinico;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    public String getRutaArchivo() {
        return rutaArchivo;
    }
    
    public void setRutaArchivo(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }
    
    public Long getTamano() {
        return tamano;
    }
    
    public void setTamano(Long tamano) {
        this.tamano = tamano;
    }
    
    public String getDescripcion() {
        return descripcion;
    }
    
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public Date getFechaSubida() {
        return fechaSubida;
    }
    
    public void setFechaSubida(Date fechaSubida) {
        this.fechaSubida = fechaSubida;
    }
    
    public String getSubidoPor() {
        return subidoPor;
    }
    
    public void setSubidoPor(String subidoPor) {
        this.subidoPor = subidoPor;
    }
    
    @Override
    public String toString() {
        return "Documento{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", tipo='" + tipo + '\'' +
                ", tamano=" + tamano +
                ", fechaSubida=" + fechaSubida +
                '}';
    }
}

