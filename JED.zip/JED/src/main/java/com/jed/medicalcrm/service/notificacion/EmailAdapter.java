package com.jed.medicalcrm.service.notificacion;

public class EmailAdapter implements Observador {
    @Override
    public void actualizar(String mensaje, String destino) {
        System.out.println("Enviando EMAIL a " + destino + ": " + mensaje);
        // Aquí iría integración real con SMTP
    }
}
