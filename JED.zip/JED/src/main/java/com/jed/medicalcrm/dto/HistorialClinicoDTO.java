package com.jed.medicalcrm.dto;

import java.util.Date;
import java.util.List;

public class HistorialClinicoDTO {
    private Long id;
    private Long pacienteId;
    private Long medicoId;  // Added to store the doctor's ID
    private String diagnostico;
    private String tratamiento;
    private String sintomas;  // Added for symptoms
    private String antecedentes;
    private String medicacion;
    private String alergias;
    private String resultadosLaboratorio;
    private String observaciones;
    private String planSeguimiento;
    private Date fechaCreacion;
    private Date ultimaActualizacion;
    private List<Long> documentosIds; // To hold document IDs

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getPacienteId() { return pacienteId; }
    public void setPacienteId(Long pacienteId) { this.pacienteId = pacienteId; }

    public Long getMedicoId() { return medicoId; }  // Added getter
    public void setMedicoId(Long medicoId) { this.medicoId = medicoId; }

    public String getDiagnostico() { return diagnostico; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }

    public String getTratamiento() { return tratamiento; }
    public void setTratamiento(String tratamiento) { this.tratamiento = tratamiento; }

    public String getSintomas() { return sintomas; }  // Added getter for sintomas
    public void setSintomas(String sintomas) { this.sintomas = sintomas; }  // Added setter for sintomas

    public String getAntecedentes() { return antecedentes; }
    public void setAntecedentes(String antecedentes) { this.antecedentes = antecedentes; }

    public String getMedicacion() { return medicacion; }
    public void setMedicacion(String medicacion) { this.medicacion = medicacion; }

    public String getAlergias() { return alergias; }
    public void setAlergias(String alergias) { this.alergias = alergias; }

    public String getResultadosLaboratorio() { return resultadosLaboratorio; }
    public void setResultadosLaboratorio(String resultadosLaboratorio) { this.resultadosLaboratorio = resultadosLaboratorio; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public String getPlanSeguimiento() { return planSeguimiento; }
    public void setPlanSeguimiento(String planSeguimiento) { this.planSeguimiento = planSeguimiento; }

    public Date getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Date fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public Date getUltimaActualizacion() { return ultimaActualizacion; }
    public void setUltimaActualizacion(Date ultimaActualizacion) { this.ultimaActualizacion = ultimaActualizacion; }

    public List<Long> getDocumentosIds() { return documentosIds; }
    public void setDocumentosIds(List<Long> documentosIds) { this.documentosIds = documentosIds; }
}
