package com.jed.medicalcrm.controller;

import com.jed.medicalcrm.dto.CitaDTO;
import com.jed.medicalcrm.service.cita.CitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/citas")
public class CitaController {

    @Autowired
    private CitaService citaService;

    /**
     * Crear una nueva cita
     */
    @PostMapping
    public ResponseEntity<CitaDTO> crearCita(@RequestBody CitaDTO citaDTO) {
        CitaDTO creada = citaService.crearCita(citaDTO);
        return ResponseEntity.ok(creada);
    }

    /**
     * Obtener todas las citas
     */
    @GetMapping
    public ResponseEntity<List<CitaDTO>> obtenerTodas() {
        List<CitaDTO> citas = citaService.obtenerTodas();
        return ResponseEntity.ok(citas);
    }
}
