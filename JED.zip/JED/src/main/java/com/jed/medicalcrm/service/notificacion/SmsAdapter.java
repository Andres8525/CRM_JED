package com.jed.medicalcrm.service.notificacion;

public class SmsAdapter implements Observador {
    @Override
    public void actualizar(String mensaje, String destino) {
        System.out.println("Enviando SMS a " + destino + ": " + mensaje);
        // Aquí iría integración real con API SMS
    }
}
