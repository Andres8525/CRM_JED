package com.jed.medicalcrm.service.historial;

import com.jed.medicalcrm.dto.HistorialClinicoDTO;
import com.jed.medicalcrm.model.HistorialClinico;
import com.jed.medicalcrm.model.Paciente;
import com.jed.medicalcrm.model.Medico;
import com.jed.medicalcrm.repository.HistorialClinicoRepository;
import com.jed.medicalcrm.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Date;
import java.util.ArrayList;

/**
 * Service for managing clinical records
 */
@Service
public class HistorialService {

    @Autowired
    private HistorialClinicoRepository historialRepo;

    @Autowired
    private UsuarioRepository usuarioRepo;

    /**
     * Creates a new clinical record using the Builder pattern
     */
    public HistorialClinicoDTO createHistorial(HistorialClinicoDTO dto) {
        // Validations for patient and doctor
        Paciente paciente = (Paciente) usuarioRepo.findById(dto.getPacienteId())
                .orElseThrow(() -> new RuntimeException("Patient not found"));

        Medico medico = (Medico) usuarioRepo.findById(dto.getMedicoId())
                .orElseThrow(() -> new RuntimeException("Doctor not found"));

        // Use the Builder pattern to create the clinical history
        HistorialClinico historial = new HistorialClinico.Builder()
                .paciente(paciente)
                .medico(medico)
                .diagnostico(dto.getDiagnostico())
                .tratamiento(dto.getTratamiento())
                .sintomas(dto.getSintomas())
                .observaciones(dto.getObservaciones())
                .build();

        // Save the historial to the database
        historial = historialRepo.save(historial);

        return convertToDTO(historial);
    }

    /**
     * Gets a clinical record by its ID
     */
    public HistorialClinicoDTO getById(Long id) {
        HistorialClinico historial = historialRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Clinical record not found"));

        return convertToDTO(historial);
    }

    /**
     * Converts a HistorialClinico object to DTO
     */
    private HistorialClinicoDTO convertToDTO(HistorialClinico historial) {
        HistorialClinicoDTO dto = new HistorialClinicoDTO();

        dto.setId(historial.getId());
        // Check if paciente and medico are not null before calling getId
        dto.setPacienteId(historial.getPaciente() != null ? historial.getPaciente().getId() : null);
        dto.setMedicoId(historial.getMedico() != null ? historial.getMedico().getId() : null);

        dto.setDiagnostico(historial.getDiagnostico());
        dto.setTratamiento(historial.getTratamiento());
        dto.setSintomas(historial.getSintomas());
        dto.setAntecedentes(historial.getAntecedentes());
        dto.setMedicacion(historial.getMedicacion());
        dto.setAlergias(historial.getAlergias());
        dto.setResultadosLaboratorio(historial.getResultadosLaboratorio());
        dto.setObservaciones(historial.getObservaciones());
        dto.setPlanSeguimiento(historial.getPlanSeguimiento());
        dto.setFechaCreacion(historial.getFechaCreacion());
        dto.setUltimaActualizacion(historial.getUltimaActualizacion());

        // If there are any attached documents, add their ids to the DTO
        if (historial.getDocumentosAdjuntos() != null && !historial.getDocumentosAdjuntos().isEmpty()) {
            List<Long> documentosIds = new ArrayList<>();
            historial.getDocumentosAdjuntos().forEach(doc -> documentosIds.add(doc.getId()));
            dto.setDocumentosIds(documentosIds);
        }

        return dto;
    }
}
