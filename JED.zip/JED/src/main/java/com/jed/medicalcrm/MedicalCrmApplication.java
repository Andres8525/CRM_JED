package com.jed.medicalcrm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalCrmApplication {

    public static void main(String[] args) {
        SpringApplication.run(MedicalCrmApplication.class, args);
        System.out.println("🚀 ¡Medical CRM arrancó como un rayo divino!");
    }
}
