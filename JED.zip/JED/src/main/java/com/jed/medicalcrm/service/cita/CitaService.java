package com.jed.medicalcrm.service.cita;

import com.jed.medicalcrm.model.Cita;
import com.jed.medicalcrm.model.Medico;
import com.jed.medicalcrm.model.Paciente;
import com.jed.medicalcrm.repository.CitaRepository;
import com.jed.medicalcrm.repository.UsuarioRepository;
import com.jed.medicalcrm.dto.CitaDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CitaService  {

    @Autowired
    private CitaRepository citaRepo;

    @Autowired
    private UsuarioRepository usuarioRepo;

    public CitaDTO crearCita(CitaDTO dto) {
        Cita cita = new Cita();
        
        // Buscar paciente y médico en la base de datos
        Paciente paciente = (Paciente) usuarioRepo.findById(dto.getPacienteId())
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
        
        Medico medico = (Medico) usuarioRepo.findById(dto.getMedicoId())
                .orElseThrow(() -> new RuntimeException("Médico no encontrado"));
        
        // Configurar cita
        cita.setPaciente(paciente);
        cita.setMedico(medico);
        cita.setFecha(dto.getFecha());
        cita.setMotivo(dto.getMotivo());
        cita.setEstado("Programada");
        
        if (dto.getDuracion() != null) {
            cita.setDuracion(dto.getDuracion());
        } else {
            cita.setDuracion(30); // duración por defecto: 30 minutos
        }
        
        // Guardar cita
        cita = citaRepo.save(cita);
        
        // Convertir a DTO y devolver
        return new CitaDTO(
            cita.getId(),
            cita.getPaciente().getId(),
            cita.getMedico().getId(),
            cita.getFecha(),
            cita.getMotivo(),
            cita.getDuracion(),
            cita.getEstado()
        );
    }

    public List<CitaDTO> obtenerTodas() {
        return citaRepo.findAll().stream()
                .map(cita -> new CitaDTO(
                    cita.getId(),
                    cita.getPaciente().getId(),
                    cita.getMedico().getId(),
                    cita.getFecha(),
                    cita.getMotivo(),
                    cita.getDuracion(),
                    cita.getEstado()
                ))
                .collect(Collectors.toList());
    }
}
