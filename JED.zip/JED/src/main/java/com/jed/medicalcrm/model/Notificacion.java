package com.jed.medicalcrm.model;

import jakarta.persistence.*;

@Entity
public class Notificacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tipo;    // email, sms, whatsapp
    private String destino;
    private String mensaje;

    // Getters y setters
}
