package com.jed.medicalcrm.dto;

import java.util.Date;

public class DocumentoDTO {
    private Long id;
    private Long historialId;
    private String nombre;
    private String tipo;
    private Long tamano;
    private String descripcion;
    private Date fechaSubida;
    private String subidoPor;
    private String urlDescarga;

    // Constructor por defecto
    public DocumentoDTO() {
    }

    // Constructor con todos los campos
    public DocumentoDTO(Long id, Long historialId, String nombre, String tipo, Long tamano, 
                       String descripcion, Date fechaSubida, String subidoPor) {
        this.id = id;
        this.historialId = historialId;
        this.nombre = nombre;
        this.tipo = tipo;
        this.tamano = tamano;
        this.descripcion = descripcion;
        this.fechaSubida = fechaSubida;
        this.subidoPor = subidoPor;
    }

    // Getters y setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getHistorialId() {
        return historialId;
    }

    public void setHistorialId(Long historialId) {
        this.historialId = historialId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Long getTamano() {
        return tamano;
    }

    public void setTamano(Long tamano) {
        this.tamano = tamano;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaSubida() {
        return fechaSubida;
    }

    public void setFechaSubida(Date fechaSubida) {
        this.fechaSubida = fechaSubida;
    }

    public String getSubidoPor() {
        return subidoPor;
    }

    public void setSubidoPor(String subidoPor) {
        this.subidoPor = subidoPor;
    }

    public String getUrlDescarga() {
        return urlDescarga;
    }

    public void setUrlDescarga(String urlDescarga) {
        this.urlDescarga = urlDescarga;
    }
}
