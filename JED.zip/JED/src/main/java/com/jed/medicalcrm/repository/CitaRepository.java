package com.jed.medicalcrm.repository;

import com.jed.medicalcrm.model.Cita;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CitaRepository extends JpaRepository<Cita, Long> {
    List<Cita> findByPacienteId(Long pacienteId);
    List<Cita> findByMedicoId(Long medicoId);
    List<Cita> findByFechaBetween(LocalDateTime inicio, LocalDateTime fin);
    List<Cita> findByEstado(String estado);
}
