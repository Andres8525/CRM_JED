package com.jed.medicalcrm.dto;

public class NotificacionDTO {
    private String tipo; // email, sms, whatsapp
    private String destino;
    private String mensaje;

    // Getters y setters
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getDestino() { return destino; }
    public void setDestino(String destino) { this.destino = destino; }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }
}
