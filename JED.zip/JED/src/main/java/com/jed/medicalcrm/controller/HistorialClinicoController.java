package com.jed.medicalcrm.controller;

import com.jed.medicalcrm.dto.HistorialClinicoDTO;
import com.jed.medicalcrm.service.historial.HistorialService;  // Corrected import for HistorialService
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/historial")
public class HistorialClinicoController {

    @Autowired
    private HistorialService historialService;  // Corrected field for HistorialService

    @PostMapping
    public ResponseEntity<HistorialClinicoDTO> createHistorial(@RequestBody HistorialClinicoDTO historialDTO) {
        HistorialClinicoDTO created = historialService.createHistorial(historialDTO);  // Corrected method call
        return ResponseEntity.ok(created);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HistorialClinicoDTO> getById(@PathVariable Long id) {
        HistorialClinicoDTO historial = historialService.getById(id);  // Corrected method call
        return ResponseEntity.ok(historial);
    }
}
