package com.jed.medicalcrm.service.notificacion;

public class EstrategiaNotificacion {

    public static Observador obtenerEstrategia(String tipo) {
        return switch (tipo.toLowerCase()) {
            case "email" -> new EmailAdapter();
            case "sms" -> new SmsAdapter();
            case "whatsapp" -> new WhatsAppAdapter();
            default -> throw new IllegalArgumentException("Tipo no soportado: " + tipo);
        };
    }
}
