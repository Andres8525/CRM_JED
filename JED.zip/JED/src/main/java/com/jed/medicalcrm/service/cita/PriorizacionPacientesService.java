package com.jed.medicalcrm.service.cita;

import com.jed.medicalcrm.model.Paciente;
import com.jed.medicalcrm.service.estructura.PacienteAVLTree;
import org.springframework.stereotype.Service;

@Service
public class PriorizacionPacientesService {

    private final PacienteAVLTree arbolPacientes = new PacienteAVLTree();

    public void agregarPaciente(Paciente paciente, int prioridad) {
        arbolPacientes.insertar(paciente, prioridad);
    }

    public Paciente obtenerPacientePrioritario() {
        return arbolPacientes.obtenerMayorPrioridad();
    }
}
