package com.jed.medicalcrm.service.usuario;

import com.jed.medicalcrm.model.Admin;
import com.jed.medicalcrm.model.Medico;
import com.jed.medicalcrm.model.Paciente;
import com.jed.medicalcrm.model.Usuario;

public class UsuarioFactory {

    public static Usuario crearUsuario(String tipo) {
        return switch (tipo.toLowerCase()) {
            case "admin" -> new Admin();
            case "medico" -> new Medico();
            case "paciente" -> new Paciente();
            default -> throw new IllegalArgumentException("Rol no reconocido: " + tipo);
        };
    }
}
