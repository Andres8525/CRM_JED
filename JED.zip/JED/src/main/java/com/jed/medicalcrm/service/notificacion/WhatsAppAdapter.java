package com.jed.medicalcrm.service.notificacion;

public class WhatsAppAdapter implements Observador {
    @Override
    public void actualizar(String mensaje, String destino) {
        System.out.println("Enviando WhatsApp a " + destino + ": " + mensaje);
        // Aquí iría integración real con Twilio o WhatsApp Business API
    }
}
