package com.jed.medicalcrm.service.usuario;

import com.jed.medicalcrm.config.JwtConfig;
import com.jed.medicalcrm.dto.UsuarioDTO;
import com.jed.medicalcrm.dto.MedicoDTO;
import com.jed.medicalcrm.dto.PacienteDTO;
import com.jed.medicalcrm.model.Usuario;
import com.jed.medicalcrm.model.Admin;
import com.jed.medicalcrm.model.Medico;
import com.jed.medicalcrm.model.Paciente;
import com.jed.medicalcrm.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepo;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private JwtConfig jwtConfig;

    public UsuarioDTO crearUsuario(UsuarioDTO dto) {
        // Validar que el username y email no existan
        if (usuarioRepo.existsByUsername(dto.getUsername())) {
            throw new RuntimeException("El nombre de usuario ya existe");
        }
        
        if (usuarioRepo.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("El email ya está registrado");
        }
        
        // Crear el tipo de usuario según el rol
        Usuario usuario = UsuarioFactory.crearUsuario(dto.getRol());
        
        // Configurar datos específicos por tipo de usuario
        if (usuario instanceof Medico && dto instanceof MedicoDTO) {
            MedicoDTO medicoDTO = (MedicoDTO) dto;
            ((Medico) usuario).setEspecialidad(medicoDTO.getEspecialidad());
            ((Medico) usuario).setNumeroLicencia(medicoDTO.getNumeroLicencia());
        } else if (usuario instanceof Paciente && dto instanceof PacienteDTO) {
            PacienteDTO pacienteDTO = (PacienteDTO) dto;
            ((Paciente) usuario).setNombreCompleto(pacienteDTO.getNombreCompleto());
            ((Paciente) usuario).setEdad(pacienteDTO.getEdad());
        }
        
        // Configurar datos comunes
        usuario.setUsername(dto.getUsername());
        usuario.setPassword(passwordEncoder.encode(dto.getPassword()));
        usuario.setEmail(dto.getEmail());
        usuario.setNombre(dto.getNombre());
        usuario.setApellido(dto.getApellido());
        usuario.setTelefono(dto.getTelefono());
        usuario.setRol(dto.getRol());
        
        // Guardar usuario
        usuario = usuarioRepo.save(usuario);
        
        // Convertir a DTO y devolver
        dto.setId(usuario.getId());
        dto.setPassword(null); // No devolver la contraseña
        
        return dto;
    }

    public String autenticar(UsuarioDTO dto) {
        // Buscar usuario por username
        Optional<Usuario> usuarioOpt = usuarioRepo.findByUsername(dto.getUsername());
        
        if (usuarioOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            
            // Verificar contraseña
            if (passwordEncoder.matches(dto.getPassword(), usuario.getPassword())) {
                // Generar token JWT
                return jwtConfig.generateToken(usuario.getUsername());
            }
        }
        
        throw new RuntimeException("Credenciales inválidas");
    }
}
