package com.jed.medicalcrm.dto;

import java.util.Date;

public class PacienteDTO extends UsuarioDTO {
    private String nombreCompleto;
    private int edad;
    private Date fechaNacimiento;
    private String genero;
    private String tipoSangre;
    private String direccion;
    private String historiaClinica;

    // Constructor por defecto
    public PacienteDTO() {
        super();
        setRol("paciente");
    }

    // Constructor con todos los campos
    public PacienteDTO(Long id, String username, String email, String nombre, String apellido, 
                      String telefono, String nombreCompleto, int edad) {
        super(id, username, email, nombre, apellido, telefono, "paciente");
        this.nombreCompleto = nombreCompleto;
        this.edad = edad;
    }

    // Getters y setters
    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getTipoSangre() {
        return tipoSangre;
    }

    public void setTipoSangre(String tipoSangre) {
        this.tipoSangre = tipoSangre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getHistoriaClinica() {
        return historiaClinica;
    }

    public void setHistoriaClinica(String historiaClinica) {
        this.historiaClinica = historiaClinica;
    }
}
