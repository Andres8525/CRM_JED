package com.jed.medicalcrm.controller;

import com.jed.medicalcrm.dto.DocumentoDTO;
import com.jed.medicalcrm.model.Documento;
import com.jed.medicalcrm.service.documento.DocumentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/documentos")
public class DocumentoController {

    @Autowired
    private DocumentoService documentoService;

    @PostMapping("/upload")
    public ResponseEntity<DocumentoDTO> subirDocumento(
            @RequestParam("file") MultipartFile file,
            @RequestParam("historialId") Long historialId,
            @RequestParam("descripcion") String descripcion,
            Authentication authentication) throws IOException {
        
        // Obtener nombre de usuario del contexto de seguridad
        String username = authentication.getName();
        
        // Guardar documento
        Documento documento = documentoService.guardarDocumento(file, historialId, descripcion, username);
        
        // Convertir a DTO
        DocumentoDTO dto = convertToDTO(documento);
        
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/historial/{historialId}")
    public ResponseEntity<List<DocumentoDTO>> listarDocumentosPorHistorial(@PathVariable Long historialId) {
        List<Documento> documentos = documentoService.obtenerDocumentosPorHistorial(historialId);
        
        List<DocumentoDTO> dtos = documentos.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
        
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<Resource> descargarDocumento(@PathVariable Long id) throws IOException {
        Documento documento = documentoService.findById(id)
                .orElseThrow(() -> new RuntimeException("Documento no encontrado"));
        
        Path path = Paths.get(documento.getRutaArchivo());
        Resource resource = new UrlResource(path.toUri());
        
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(documento.getTipo()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + documento.getNombre() + "\"")
                .body(resource);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDocumento(@PathVariable Long id) throws IOException {
        documentoService.eliminarDocumento(id);
        return ResponseEntity.noContent().build();
    }
    
    private DocumentoDTO convertToDTO(Documento documento) {
        DocumentoDTO dto = new DocumentoDTO();
        dto.setId(documento.getId());
        dto.setHistorialId(documento.getHistorialClinico().getId());
        dto.setNombre(documento.getNombre());
        dto.setTipo(documento.getTipo());
        dto.setTamano(documento.getTamano());
        dto.setDescripcion(documento.getDescripcion());
        dto.setFechaSubida(documento.getFechaSubida());
        dto.setSubidoPor(documento.getSubidoPor());
        
        // Crear URL de descarga
        String downloadUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/api/documentos/download/")
                .path(documento.getId().toString())
                .toUriString();
        dto.setUrlDescarga(downloadUrl);
        
        return dto;
    }
}
