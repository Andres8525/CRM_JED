

package com.jed.medicalcrm.model;

import jakarta.persistence.Entity;

@Entity
public class Admin extends Usuario {
    // Acceso total al sistema (hereda todo)
    
    // Constructor por defecto requerido por JPA
    public Admin() {
    }
}
