package com.jed.medicalcrm.repository;

import com.jed.medicalcrm.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificacionRepository extends JpaRepository<Notificacion, Long> {
}
