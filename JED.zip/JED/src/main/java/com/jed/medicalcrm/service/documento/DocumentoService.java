package com.jed.medicalcrm.service.documento;

import com.jed.medicalcrm.model.Documento;
import com.jed.medicalcrm.model.HistorialClinico;
import com.jed.medicalcrm.repository.DocumentoRepository;
import com.jed.medicalcrm.repository.HistorialClinicoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class DocumentoService {

    @Autowired
    private DocumentoRepository documentoRepo;

    @Autowired
    private HistorialClinicoRepository historialRepo;
    
    @Value("${app.upload.dir:${user.home}/medicalcrm/uploads}")
    private String uploadDir;
    
    public Documento guardarDocumento(MultipartFile file, Long historialId, String descripcion, String subidoPor) 
            throws IOException {
        
        // Verificar que el historial clínico existe
        HistorialClinico historial = historialRepo.findById(historialId)
                .orElseThrow(() -> new RuntimeException("Historial clínico no encontrado"));
        
        // Crear directorio si no existe
        Path dirPath = Paths.get(uploadDir);
        if (!Files.exists(dirPath)) {
            Files.createDirectories(dirPath);
        }
        
        // Generar nombre único para el archivo
        String originalFileName = file.getOriginalFilename();
        String fileExtension = "";
        if (originalFileName != null && originalFileName.contains(".")) {
            fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
        }
        String newFileName = UUID.randomUUID().toString() + fileExtension;
        
        // Guardar archivo en el sistema de archivos
        Path targetPath = dirPath.resolve(newFileName);
        Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);
        
        // Crear objeto Documento
        Documento documento = new Documento();
        documento.setHistorialClinico(historial);
        documento.setNombre(originalFileName);
        documento.setTipo(file.getContentType());
        documento.setRutaArchivo(targetPath.toString());
        documento.setTamano(file.getSize());
        documento.setDescripcion(descripcion);
        documento.setSubidoPor(subidoPor);
        
        // Guardar en la base de datos
        return documentoRepo.save(documento);
    }
    
    public Optional<Documento> findById(Long id) {
        return documentoRepo.findById(id);
    }
    
    public List<Documento> obtenerDocumentosPorHistorial(Long historialId) {
        return documentoRepo.findByHistorialClinicoId(historialId);
    }
    
    public void eliminarDocumento(Long documentoId) throws IOException {
        Documento documento = documentoRepo.findById(documentoId)
                .orElseThrow(() -> new RuntimeException("Documento no encontrado"));
        
        // Eliminar archivo del sistema de archivos
        Path path = Paths.get(documento.getRutaArchivo());
        if (Files.exists(path)) {
            Files.delete(path);
        }
        
        // Eliminar registro de la base de datos
        documentoRepo.delete(documento);
    }
    
    public List<Documento> buscarPorNombre(String nombre) {
        return documentoRepo.findByNombreContainingIgnoreCase(nombre);
    }
    
    public List<Documento> buscarPorTipo(String tipo) {
        return documentoRepo.findByTipo(tipo);
    }
}
