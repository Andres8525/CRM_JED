package com.jed.medicalcrm.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
public class Medico extends Usuario {
    
    private String especialidad;
    private String numeroLicencia;
    
    @OneToMany(mappedBy = "medico")
    private List<HistorialClinico> historialClinico = new ArrayList<>();
    
    // Constructor por defecto requerido por JPA
    public Medico() {
    }
    
    // Getters y Setters
    public String getEspecialidad() {
        return especialidad;
    }
    
    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }
    
    public String getNumeroLicencia() {
        return numeroLicencia;
    }
    
    public void setNumeroLicencia(String numeroLicencia) {
        this.numeroLicencia = numeroLicencia;
    }
    
    public List<HistorialClinico> getHistorialClinico() {
        return historialClinico;
    }
    
    public void setHistorialClinico(List<HistorialClinico> historialClinico) {
        this.historialClinico = historialClinico;
    }
}
