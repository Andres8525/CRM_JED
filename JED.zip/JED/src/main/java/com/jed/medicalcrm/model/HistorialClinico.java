package com.jed.medicalcrm.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

/**
 * Entidad que representa el historial clínico de un paciente
 */
@Entity
@Table(name = "historiales_clinicos")
public class HistorialClinico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "paciente_id", nullable = false)
    private Paciente paciente;

    @ManyToOne
    @JoinColumn(name = "medico_id", nullable = false)
    private Medico medico;

    @Column(length = 1000)
    private String diagnostico;

    @Column(length = 1000)
    private String tratamiento;

    @Column(length = 1000)
    private String sintomas;

    @Column(length = 1000)
    private String antecedentes;

    @Column(length = 1000)
    private String medicacion;

    @Column(length = 500)
    private String alergias;

    @Column(length = 1000)
    private String resultadosLaboratorio;

    @Column(length = 1000)
    private String observaciones;

    @Column(length = 1000)
    private String planSeguimiento;

    @OneToMany(mappedBy = "historialClinico", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Documento> documentosAdjuntos = new ArrayList<>();

    @Temporal(TemporalType.TIMESTAMP)
    @Column(nullable = false, updatable = false)
    private Date fechaCreacion = new Date();

    @Temporal(TemporalType.TIMESTAMP)
    private Date ultimaActualizacion = new Date();

    // Constructor por defecto requerido por JPA
    public HistorialClinico() {
    }

    // Getters y Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getTratamiento() {
        return tratamiento;
    }

    public void setTratamiento(String tratamiento) {
        this.tratamiento = tratamiento;
    }

    public String getSintomas() {
        return sintomas;
    }

    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }

    public String getAntecedentes() {
        return antecedentes;
    }

    public void setAntecedentes(String antecedentes) {
        this.antecedentes = antecedentes;
    }

    public String getMedicacion() {
        return medicacion;
    }

    public void setMedicacion(String medicacion) {
        this.medicacion = medicacion;
    }

    public String getAlergias() {
        return alergias;
    }

    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    public String getResultadosLaboratorio() {
        return resultadosLaboratorio;
    }

    public void setResultadosLaboratorio(String resultadosLaboratorio) {
        this.resultadosLaboratorio = resultadosLaboratorio;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getPlanSeguimiento() {
        return planSeguimiento;
    }

    public void setPlanSeguimiento(String planSeguimiento) {
        this.planSeguimiento = planSeguimiento;
    }

    public List<Documento> getDocumentosAdjuntos() {
        return documentosAdjuntos;
    }

    public void setDocumentosAdjuntos(List<Documento> documentosAdjuntos) {
        this.documentosAdjuntos = documentosAdjuntos;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Date getUltimaActualizacion() {
        return ultimaActualizacion;
    }

    public void setUltimaActualizacion(Date ultimaActualizacion) {
        this.ultimaActualizacion = ultimaActualizacion;
    }

    // Pre-Actualizar
    @PreUpdate
    public void preActualizar() {
        this.ultimaActualizacion = new Date();
    }

    /**
     * Implementación del patrón Builder para HistorialClinico
     */
    public static class Builder {
        private HistorialClinico historial;

        public Builder() {
            historial = new HistorialClinico();
        }

        public Builder paciente(Paciente paciente) {
            historial.setPaciente(paciente);
            return this;
        }

        public Builder medico(Medico medico) {
            historial.setMedico(medico);
            return this;
        }

        public Builder diagnostico(String diagnostico) {
            historial.setDiagnostico(diagnostico);
            return this;
        }

        public Builder tratamiento(String tratamiento) {
            historial.setTratamiento(tratamiento);
            return this;
        }

        public Builder sintomas(String sintomas) {
            historial.setSintomas(sintomas);
            return this;
        }

        public Builder antecedentes(String antecedentes) {
            historial.setAntecedentes(antecedentes);
            return this;
        }

        public Builder medicacion(String medicacion) {
            historial.setMedicacion(medicacion);
            return this;
        }

        public Builder alergias(String alergias) {
            historial.setAlergias(alergias);
            return this;
        }

        public Builder resultadosLaboratorio(String resultados) {
            historial.setResultadosLaboratorio(resultados);
            return this;
        }

        public Builder observaciones(String observaciones) {
            historial.setObservaciones(observaciones);
            return this;
        }

        public Builder planSeguimiento(String plan) {
            historial.setPlanSeguimiento(plan);
            return this;
        }

        public Builder agregarDocumento(Documento documento) {
            if (documento != null) {
                historial.getDocumentosAdjuntos().add(documento);
            }
            return this;
        }

        public Builder agregarDocumentos(List<Documento> documentos) {
            if (documentos != null && !documentos.isEmpty()) {
                historial.getDocumentosAdjuntos().addAll(documentos);
            }
            return this;
        }

        public Builder fechaCreacion(Date fechaCreacion) {
            if (fechaCreacion != null) {
                historial.setFechaCreacion(fechaCreacion);
            }
            return this;
        }

        public Builder ultimaActualizacion(Date ultimaActualizacion) {
            if (ultimaActualizacion != null) {
                historial.setUltimaActualizacion(ultimaActualizacion);
            }
            return this;
        }

        public HistorialClinico build() {
            // Validaciones
            if (historial.getPaciente() == null) {
                throw new IllegalStateException("El historial clínico requiere un paciente");
            }
            if (historial.getMedico() == null) {
                throw new IllegalStateException("El historial clínico requiere un médico");
            }

            return historial;
        }
    }
}
