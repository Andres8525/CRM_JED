package com.jed.medicalcrm.dto;

public class MedicoDTO extends UsuarioDTO {
    private String especialidad;
    private String numeroLicencia;

    // Constructor por defecto
    public MedicoDTO() {
        super();
        setRol("medico");
    }

    // Constructor con todos los campos
    public MedicoDTO(Long id, String username, String email, String nombre, String apellido, 
                    String telefono, String especialidad, String numeroLicencia) {
        super(id, username, email, nombre, apellido, telefono, "medico");
        this.especialidad = especialidad;
        this.numeroLicencia = numeroLicencia;
    }

    // Getters y setters
    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getNumeroLicencia() {
        return numeroLicencia;
    }

    public void setNumeroLicencia(String numeroLicencia) {
        this.numeroLicencia = numeroLicencia;
    }
}
