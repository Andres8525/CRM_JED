package com.jed.medicalcrm.service.notificacion;

public interface Observador {
    void actualizar(String mensaje, String destino);
}
