package com.jed.medicalcrm.controller;

import com.jed.medicalcrm.dto.NotificacionDTO;
import com.jed.medicalcrm.service.notificacion.NotificacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notificaciones")
public class NotificacionController {

    @Autowired
    private NotificacionService notificacionService;

    @PostMapping
    public ResponseEntity<String> enviar(@RequestBody NotificacionDTO dto) {
        notificacionService.enviarNotificacion(dto);
        return ResponseEntity.ok("Notificación enviada");
    }
}
